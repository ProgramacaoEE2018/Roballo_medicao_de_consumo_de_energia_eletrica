var searchData=
[
  ['serial',['Serial',['../class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html#a7f6bc41a9740f221de8d6ddee8c9f09a',1,'Projeto_Roballo_Arduino_medidor_de_energia::Medidor_de_Energia']]],
  ['sp_5fdatareceived',['SP_DataReceived',['../class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html#a67ed703924b482ddb03add1c0fdf90c8',1,'Projeto_Roballo_Arduino_medidor_de_energia::Medidor_de_Energia']]]
];
