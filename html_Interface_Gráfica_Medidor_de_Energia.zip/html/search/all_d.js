var searchData=
[
  ['x',['X',['../class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html#a650eb47fcae8c003fab3bd152322e8ab',1,'Projeto_Roballo_Arduino_medidor_de_energia::Medidor_de_Energia']]]
];
