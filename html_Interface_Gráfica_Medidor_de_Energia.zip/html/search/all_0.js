var searchData=
[
  ['atualizalistacoms',['atualizaListaCOMs',['../class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html#aca7c62123ae77800fd8559b8a85b6569',1,'Projeto_Roballo_Arduino_medidor_de_energia::Medidor_de_Energia']]]
];
