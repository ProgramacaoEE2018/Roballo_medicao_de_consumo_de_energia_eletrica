var searchData=
[
  ['q',['Q',['../class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html#a0863939b4916c5f2dbd57ac69f59540e',1,'Projeto_Roballo_Arduino_medidor_de_energia::Medidor_de_Energia']]]
];
