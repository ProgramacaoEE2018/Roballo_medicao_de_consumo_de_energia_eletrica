var searchData=
[
  ['dispose',['Dispose',['../class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html#a4c390bc8e6d495027877528b7ae4d315',1,'Projeto_Roballo_Arduino_medidor_de_energia::Medidor_de_Energia']]]
];
