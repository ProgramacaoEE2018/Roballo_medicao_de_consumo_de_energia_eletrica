var searchData=
[
  ['sp',['SP',['../class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html#af9347dc5cdfc85a8c89d54cb98ea3fe1',1,'Projeto_Roballo_Arduino_medidor_de_energia::Medidor_de_Energia']]]
];
