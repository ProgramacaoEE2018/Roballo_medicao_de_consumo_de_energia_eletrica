var searchData=
[
  ['groupbox1',['groupBox1',['../class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html#a4342c04c4c10a7a4f1176a510ed0c784',1,'Projeto_Roballo_Arduino_medidor_de_energia::Medidor_de_Energia']]],
  ['groupbox2',['groupBox2',['../class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html#a090cd74bcff886af973a69c81c739acc',1,'Projeto_Roballo_Arduino_medidor_de_energia::Medidor_de_Energia']]]
];
