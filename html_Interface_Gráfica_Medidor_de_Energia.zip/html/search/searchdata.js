var indexSectionsWithContent =
{
  0: "abcdfgilmpqstx",
  1: "mp",
  2: "p",
  3: "fp",
  4: "abcdfilmst",
  5: "bcglpqstx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Namespaces",
  3: "Arquivos",
  4: "Funções",
  5: "Variáveis"
};

