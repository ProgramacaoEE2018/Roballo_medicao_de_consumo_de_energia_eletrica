var hierarchy =
[
    [ "Form", null, [
      [ "Projeto_Roballo_Arduino_medidor_de_energia.Medidor_de_Energia", "class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html", null ]
    ] ],
    [ "Projeto_Roballo_Arduino_medidor_de_energia.Program", "class_projeto___roballo___arduino__medidor__de__energia_1_1_program.html", null ]
];