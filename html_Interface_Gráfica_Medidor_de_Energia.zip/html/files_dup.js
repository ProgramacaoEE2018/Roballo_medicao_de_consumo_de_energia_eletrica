var files_dup =
[
    [ "Form1.cs", "_form1_8cs.html", [
      [ "Medidor_de_Energia", "class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html", "class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia" ]
    ] ],
    [ "Form1.Designer.cs", "_form1_8_designer_8cs.html", [
      [ "Medidor_de_Energia", "class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html", "class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia" ]
    ] ],
    [ "Program.cs", "_program_8cs.html", [
      [ "Program", "class_projeto___roballo___arduino__medidor__de__energia_1_1_program.html", "class_projeto___roballo___arduino__medidor__de__energia_1_1_program" ]
    ] ]
];