var namespace_projeto___roballo___arduino__medidor__de__energia =
[
    [ "Medidor_de_Energia", "class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia.html", "class_projeto___roballo___arduino__medidor__de__energia_1_1_medidor__de___energia" ],
    [ "Program", "class_projeto___roballo___arduino__medidor__de__energia_1_1_program.html", "class_projeto___roballo___arduino__medidor__de__energia_1_1_program" ]
];