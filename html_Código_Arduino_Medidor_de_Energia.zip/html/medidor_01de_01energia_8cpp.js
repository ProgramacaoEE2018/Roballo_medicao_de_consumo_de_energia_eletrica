var medidor_01de_01energia_8cpp =
[
    [ "Dados", "class_dados.html", "class_dados" ],
    [ "ADC_BITS", "medidor_01de_01energia_8cpp.html#ae678d504181814806fe8acf281cb7c31", null ],
    [ "ADC_COUNTS", "medidor_01de_01energia_8cpp.html#a0bd163f27989d621e866746458db1d08", null ],
    [ "LE_TENSAO_CALIBRATION_CONST", "medidor_01de_01energia_8cpp.html#a6b487d03dc48b32547701a34e73ee53a", null ],
    [ "loop", "medidor_01de_01energia_8cpp.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "medidor_01de_01energia_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "emon1", "medidor_01de_01energia_8cpp.html#a77d3e4c2b65d99e8acf860724775eb6a", null ],
    [ "pino_sct", "medidor_01de_01energia_8cpp.html#a54b992cebab2027c397104e1c3f6c9ea", null ]
];