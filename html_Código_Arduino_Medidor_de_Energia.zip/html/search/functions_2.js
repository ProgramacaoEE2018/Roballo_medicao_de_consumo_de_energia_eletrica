var searchData=
[
  ['le_5ftensao',['le_tensao',['../class_dados.html#a86d5d3d4475a6ab54f4aeda1dee7333b',1,'Dados']]],
  ['loop',['loop',['../medidor_01de_01energia_8cpp.html#afe461d27b9c48d5921c00d521181f12f',1,'medidor de energia.cpp']]]
];
