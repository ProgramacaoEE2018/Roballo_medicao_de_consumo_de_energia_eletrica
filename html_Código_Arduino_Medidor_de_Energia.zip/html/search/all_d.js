var searchData=
[
  ['vcal',['VCAL',['../class_dados.html#af3a9d5407e8d2a6f35ae7a6dc8a272a1',1,'Dados']]],
  ['vrms',['Vrms',['../class_dados.html#a43b185880984da3a74f9cbc587552d36',1,'Dados']]]
];
