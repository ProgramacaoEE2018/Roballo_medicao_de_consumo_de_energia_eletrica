var searchData=
[
  ['setcorrentetx',['setcorrenteTX',['../class_dados.html#a9483839482ba2d9fb442b06204b7fe60',1,'Dados']]],
  ['settensaotx',['settensaoTX',['../class_dados.html#a62694c250151a94bbd76fc9923ca45b7',1,'Dados']]],
  ['setup',['setup',['../medidor_01de_01energia_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'medidor de energia.cpp']]]
];
