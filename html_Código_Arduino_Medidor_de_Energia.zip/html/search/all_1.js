var searchData=
[
  ['calc_5fcorrente_5frms',['calc_corrente_rms',['../class_dados.html#ada19523717d6aa3a30572650ba8ac0dc',1,'Dados']]],
  ['calculo_5fpotencia',['calculo_Potencia',['../class_dados.html#aba5bee8050d2dc72ae90eb34518e6196',1,'Dados']]],
  ['checkvcross',['checkVCross',['../class_dados.html#acad3792b55e3e4c2478c18a53a66deee',1,'Dados']]]
];
