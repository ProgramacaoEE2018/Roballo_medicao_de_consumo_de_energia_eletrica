var searchData=
[
  ['offseti',['offsetI',['../class_dados.html#ad62ef4e7aea095be79f90d95677edea9',1,'Dados']]],
  ['offsetv',['offsetV',['../class_dados.html#ad98dea3c4ee22e6db888130ad7b655d5',1,'Dados']]]
];
