var searchData=
[
  ['lastfilteredv',['lastFilteredV',['../class_dados.html#ab569644dd1b7e5647494c9e2d28d7c3b',1,'Dados']]],
  ['lastvcross',['lastVCross',['../class_dados.html#a0b7fcc84c1dbf725e886a92ec5ef7017',1,'Dados']]]
];
