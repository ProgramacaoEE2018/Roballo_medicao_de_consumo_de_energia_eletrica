var searchData=
[
  ['filteredi',['filteredI',['../class_dados.html#ab93bfda3b94d0d0940f3fa5dac887ae0',1,'Dados']]],
  ['filteredv',['filteredV',['../class_dados.html#a6ec055c014d17f5becae8903d8dfe18c',1,'Dados']]]
];
