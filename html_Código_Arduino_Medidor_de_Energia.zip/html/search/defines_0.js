var searchData=
[
  ['adc_5fbits',['ADC_BITS',['../medidor_01de_01energia_8cpp.html#ae678d504181814806fe8acf281cb7c31',1,'medidor de energia.cpp']]],
  ['adc_5fcounts',['ADC_COUNTS',['../medidor_01de_01energia_8cpp.html#a0bd163f27989d621e866746458db1d08',1,'medidor de energia.cpp']]]
];
