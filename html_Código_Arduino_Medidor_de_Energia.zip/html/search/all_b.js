var searchData=
[
  ['realpower',['realPower',['../class_dados.html#a899203d238e5f77a4fcc326407a5717c',1,'Dados']]]
];
