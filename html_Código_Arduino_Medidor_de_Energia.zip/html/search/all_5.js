var searchData=
[
  ['getcorrente',['getcorrente',['../class_dados.html#a626665e9dad169a9d8aa4fb8b1a62981',1,'Dados']]],
  ['gettensao',['gettensao',['../class_dados.html#acd1ea33bcd4b2c10cd902fb8b11409a4',1,'Dados']]]
];
