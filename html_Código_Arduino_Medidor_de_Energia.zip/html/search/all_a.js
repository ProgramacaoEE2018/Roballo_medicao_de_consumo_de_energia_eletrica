var searchData=
[
  ['phasecal',['PHASECAL',['../class_dados.html#a737cde39938588e5666b2192e012a6cb',1,'Dados']]],
  ['phaseshiftedv',['phaseShiftedV',['../class_dados.html#a290314e3f9c32258894129eb090a415c',1,'Dados']]],
  ['pino_5fsct',['pino_sct',['../medidor_01de_01energia_8cpp.html#a54b992cebab2027c397104e1c3f6c9ea',1,'medidor de energia.cpp']]],
  ['powerfactor',['powerFactor',['../class_dados.html#a1cbd03d1cf8bc9fb5b6b5753c70d3b76',1,'Dados']]]
];
