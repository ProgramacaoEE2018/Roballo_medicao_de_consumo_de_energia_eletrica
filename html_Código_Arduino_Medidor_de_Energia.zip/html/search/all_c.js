var searchData=
[
  ['samplei',['sampleI',['../class_dados.html#ae8ea3b69343588316bb336c3fc193a30',1,'Dados']]],
  ['samplev',['sampleV',['../class_dados.html#a0f41d652dbc38aae27bf044c008aa9a9',1,'Dados']]],
  ['setcorrentetx',['setcorrenteTX',['../class_dados.html#a9483839482ba2d9fb442b06204b7fe60',1,'Dados']]],
  ['settensaotx',['settensaoTX',['../class_dados.html#a62694c250151a94bbd76fc9923ca45b7',1,'Dados']]],
  ['setup',['setup',['../medidor_01de_01energia_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'medidor de energia.cpp']]],
  ['sqi',['sqI',['../class_dados.html#a254595b106b2c508964e060851c64912',1,'Dados']]],
  ['sqv',['sqV',['../class_dados.html#a5e0045d582a5076d264b5a146a02a175',1,'Dados']]],
  ['startv',['startV',['../class_dados.html#add390a31b2cf2bfd601d0e11703b8623',1,'Dados']]],
  ['sumi',['sumI',['../class_dados.html#ad8c4ae8b881268e9c98278ce2f70f1f8',1,'Dados']]],
  ['sump',['sumP',['../class_dados.html#a9f5373f26ea952de67036a5af613ca83',1,'Dados']]],
  ['sumv',['sumV',['../class_dados.html#a25fb9fd10d7e1d150a865907c9821fe1',1,'Dados']]]
];
