var searchData=
[
  ['apparentpower',['apparentPower',['../class_dados.html#a592430d1386857e2ee27d964c7f78f35',1,'Dados']]]
];
