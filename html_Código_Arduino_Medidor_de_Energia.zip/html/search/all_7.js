var searchData=
[
  ['lastfilteredv',['lastFilteredV',['../class_dados.html#ab569644dd1b7e5647494c9e2d28d7c3b',1,'Dados']]],
  ['lastvcross',['lastVCross',['../class_dados.html#a0b7fcc84c1dbf725e886a92ec5ef7017',1,'Dados']]],
  ['le_5ftensao',['le_tensao',['../class_dados.html#a86d5d3d4475a6ab54f4aeda1dee7333b',1,'Dados']]],
  ['le_5ftensao_5fcalibration_5fconst',['LE_TENSAO_CALIBRATION_CONST',['../medidor_01de_01energia_8cpp.html#a6b487d03dc48b32547701a34e73ee53a',1,'medidor de energia.cpp']]],
  ['loop',['loop',['../medidor_01de_01energia_8cpp.html#afe461d27b9c48d5921c00d521181f12f',1,'medidor de energia.cpp']]]
];
