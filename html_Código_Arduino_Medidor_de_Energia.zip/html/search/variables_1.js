var searchData=
[
  ['checkvcross',['checkVCross',['../class_dados.html#acad3792b55e3e4c2478c18a53a66deee',1,'Dados']]]
];
