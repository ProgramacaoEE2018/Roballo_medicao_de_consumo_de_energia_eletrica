var files_dup =
[
    [ "medidor de energia.cpp", "medidor_01de_01energia_8cpp.html", "medidor_01de_01energia_8cpp" ]
];